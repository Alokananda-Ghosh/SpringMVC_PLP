package com.cg.xyzbank.service;

import java.util.List;

import com.cg.xyzbank.bean.Customer;

public interface ICustomerService {
	public int addCustomer(Customer customer);

	public void depositMoney(int id, double amt);

	public void withdrawMoney(int id, double amt);

	public void fundTransfer(int id, int id2, double amt);

	public List<Customer> getAllDetails();

	public Customer showBalance(int id);

}
