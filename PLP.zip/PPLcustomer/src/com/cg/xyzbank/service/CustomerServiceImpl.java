package com.cg.xyzbank.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.dao.CustomerDaoImpl;
import com.cg.xyzbank.dao.ICustomerDao;

@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	ICustomerDao objDao=new CustomerDaoImpl();

	public ICustomerDao getObjDao() {
		return objDao;
	}

	public void setObjDao(ICustomerDao objDao) {
		this.objDao = objDao;
	}
	
	public int addCustomer(Customer customer)
	{
		
		return objDao.addCustomer(customer);
	}

	@Override
	public void depositMoney(int id, double amt) {
		// TODO Auto-generated method stub
		
		objDao.depositMoney(id,amt);
	}

	@Override
	public void withdrawMoney(int id, double amt) {
		// TODO Auto-generated method stub
		objDao.withdrawMoney(id,amt);
	}

	@Override
	public void fundTransfer(int id, int id2, double amt) {
		// TODO Auto-generated method stub
		objDao.fundTransfer(id,id2, amt);
	}

	@Override
	public List<Customer> getAllDetails() {
		// TODO Auto-generated method stub
		return objDao.getAllDetails();
	}

	@Override
	public Customer showBalance(int id) {
		// TODO Auto-generated method stub
		return objDao.showBalance(id);
	}

}
