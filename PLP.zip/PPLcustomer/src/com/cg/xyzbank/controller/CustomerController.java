package com.cg.xyzbank.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	private ICustomerService obService;

	public ICustomerService getObService() {
		return obService;
	}

	public void setObService(ICustomerService obService) {
		this.obService = obService;
	}
	
	@RequestMapping("/showAddCustomer")
	public ModelAndView showAddTrainee()
	{
		Customer customer=new Customer();
		
		return new ModelAndView("AddCustomer","customer",customer);
	}
	@RequestMapping("/addCustomer")
	public ModelAndView addTrainee(@ModelAttribute("customer") @Valid Customer customer,
			BindingResult result)
	 {
		ModelAndView mv = null;
		
		if (!result.hasErrors()) {
			

			int id=obService.addCustomer(customer);
			

			mv = new ModelAndView("Success","id",id);
			
			
		} else {
			

			mv = new ModelAndView("AddCustomer", "customer", customer);
		}
		

		return mv;
	 }
	@RequestMapping("/showHome")
	public String showHome()
	{
		return "Home";
		
	}
	@RequestMapping("/showDepositMoney")
	public String showDepositMoney()
	{
		return "DepositMoney";
		
	}
	
	@RequestMapping("/depositMoney")
	public ModelAndView depositMoney(@RequestParam("id") int id,
			@RequestParam("amt") double amt,Model m)
	{
		
		obService.depositMoney(id,amt);
		
		return new ModelAndView("Success","id",id);
		
	}
	@RequestMapping("/showWithdrawMoney")
	public String WithdrawMoney()
	{
		return "WithdrawMoney";
		
	}
	@RequestMapping("/withdrawMoney")
	public ModelAndView withdrawMoney(@RequestParam("id") int id,
			@RequestParam("amt") double amt,Model m)
	{
		
		obService.withdrawMoney(id,amt);
		
		return new ModelAndView("Success","id",id);
		
	}
	@RequestMapping("/showFundTransfer")
	public String showFundTransfer()
	{
		return "FundTransfer";
		
	}
	@RequestMapping("/fundTransfer")
	public ModelAndView fundTransfer(@RequestParam("id") int id,@RequestParam("id2") int id2,
			@RequestParam("amt") double amt,Model m)
	{
		
		obService.fundTransfer(id,id2,amt);
		
		return new ModelAndView("Success","id",id);
		
	}
	@RequestMapping("/showCustomers")
	public ModelAndView showCustomers() {

		ModelAndView mv = new ModelAndView();

		List<Customer> list = obService.getAllDetails();

			mv.setViewName("ShowCustomers");
			// Add the attribute to the model
			mv.addObject("list", list);
			System.out.println(list);
		return mv;
	}
	@RequestMapping("/showShowBalance")
	public String showShowBalance()
	{
		return "ShowBalance";
		
	}
	@RequestMapping("/showBalance")
	public ModelAndView showBalance(@RequestParam("id") int id,Model m) {

		ModelAndView mv = new ModelAndView();
		
		Customer customer=obService.showBalance(id);

			mv.setViewName("ShowCustomers");
			// Add the attribute to the model
			mv.addObject("balance",customer.getBalance());
			
		return mv;
	}
	
	
}
