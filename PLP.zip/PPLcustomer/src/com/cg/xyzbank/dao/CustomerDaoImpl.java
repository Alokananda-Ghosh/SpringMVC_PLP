package com.cg.xyzbank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.xyzbank.bean.Customer;

@Repository
public class CustomerDaoImpl implements ICustomerDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addCustomer(Customer customer) {
		// TODO Auto-generated method stub
	

		entityManager.persist(customer);
		
		entityManager.flush();
		 return customer.getId();
	
	}

	@Override
	public void depositMoney(int id, double amt) {
		// TODO Auto-generated method stub
		
		Customer customer=entityManager.find(Customer.class,id);
	
		customer.setBalance(amt+customer.getBalance());
	
		entityManager.merge(customer);
	}

	@Override
	public void withdrawMoney(int id, double amt) {
		// TODO Auto-generated method stub
		
		Customer customer=entityManager.find(Customer.class,id);
		double bal=customer.getBalance()-amt;
		if(bal>=0)
			customer.setBalance(customer.getBalance()-amt);
		
		entityManager.merge(customer);
	}

	@Override
	public void fundTransfer(int id, int id2, double amt) {
		// TODO Auto-generated method stub
		Customer customer=entityManager.find(Customer.class,id);
		Customer customer2=entityManager.find(Customer.class,id2);
		double bal=customer.getBalance()-amt;
		if(bal>=0)
		{
			customer.setBalance(bal);
			customer2.setBalance(customer2.getBalance()+amt);
		}
		entityManager.merge(customer);
		entityManager.merge(customer2);
		
	}

	@Override
	public List<Customer> getAllDetails() {
		// TODO Auto-generated method stub
		
		TypedQuery<Customer> query = entityManager.createQuery("SELECT customer FROM Customer customer", Customer.class);
		System.out.println(query.getResultList());
		return query.getResultList();
		
	}

	@Override
	public Customer showBalance(int id) {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query = entityManager.createQuery("SELECT customer FROM Customer customer where id=:pid", Customer.class);
		query.setParameter("pid", id);
		System.out.println(query.getSingleResult());
		return null;
	}
	
	
	
	

}
