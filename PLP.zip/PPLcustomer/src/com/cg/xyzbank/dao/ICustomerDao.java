package com.cg.xyzbank.dao;

import java.util.List;

import com.cg.xyzbank.bean.Customer;

public interface ICustomerDao {

	int addCustomer(Customer customer);

	void depositMoney(int id, double amt);

	void withdrawMoney(int id, double amt);

	void fundTransfer(int id, int id2, double amt);

	List<Customer> getAllDetails();

	Customer showBalance(int id);

}
